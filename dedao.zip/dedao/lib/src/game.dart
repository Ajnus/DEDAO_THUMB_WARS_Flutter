import 'package:flutter/material.dart';
import 'package:audioplayers/audio_cache.dart';
//import 'package:flare_flutter/flare_actor.dart';



class GamePage extends StatefulWidget {
 
  @override
  _GamePageState createState() => _GamePageState();
  //_Animation createState() => _MyHomePageState();
}

/*class _Animation extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return new FlareActor("assets/Meditating.flr",
        alignment: Alignment.center, fit: BoxFit.contain, animation: "idle");
  }
}*/

class _GamePageState extends State<GamePage> {
  int _counter = 0;
  static AudioCache player = new AudioCache();
  static const audioPath = 'clash 01.mp3';
  static const audioPath2 = 'Spin 1.mp3';
  static const audioPath3 = "John Williams - Duel of the Fates (Star Wars Soundtrack) [HD].mp3";

  void _incrementCounter() {
    setState(() {
      player.play(audioPath2);
     // Scaffold.backgroundColor: Color.red;
      _counter++;
    });
  } 

  void _hello() {
    setState(() {
      player.play(audioPath3);
    });
  }

  void _decrementCounter() {
    setState(() {
      player.play(audioPath);
      _counter--;
    });
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('DEDÃO WARS'),
        textTheme: TextTheme(
          title: TextStyle(
            fontFamily: 'StarJedi',
            color: Color(0xFFFFFF00),
            fontSize: 25.0,
          ),
        ),
      ),
      body: /*Container(
        child:*/ Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset('assets/vadervsobiwan.jpg'),
              if (_counter > 0)
                Text('The Dark side the Force wins by these many times:')
              else
                if (_counter < 0)
                  Text('The Light side the Force wins by these many times:')
                else
                  Text('The Balance of the Force wins.'),
              Text(
                '$_counter',
                style: Theme.of(context).textTheme.display1,
              ),
              Image.asset('assets/flaws.jpg'),
            ],
          ),
        ),
      //),
      bottomNavigationBar: BottomAppBar(
        color: Colors.black,
        child: Container(height: 50.0),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton:
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //crossAxisAlignment: CrossAxisAlignment.baseline,
              children: <Widget>[
            FloatingActionButton(
              backgroundColor: Colors.red,
              onPressed: _incrementCounter,
              tooltip: 'Sith Rage',
              child: Icon(Icons.add),
            ),
            FloatingActionButton(
              onPressed: _hello,
              backgroundColor: Colors.purple,
              tooltip: 'HELLO THERE!',
              child: Icon(Icons.music_note),
            ),
            FloatingActionButton(
              backgroundColor: Colors.blue,
              onPressed: _decrementCounter,
              tooltip: 'Jedi Balance',
              child: Icon(Icons.remove),
            ),
          ]),
    );
  }
}
